
SafeNet Sentinel:
для просмотра доступных ключей нужно установить
shk-licmon-1.0.2-0.i386.rpm
shk-license-manager-1.0.2-0.i386.rpm

для многих систем понадобится параметр --noscripts при установке
